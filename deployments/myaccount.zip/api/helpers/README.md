Place helper files in this directory.

This is also the directory that will be checked for Volos functions.
