'use strict';

module.exports = {
  getBitrateList: getBitrateList,
  createBitrate: createBitrate
};

function getBitrateList(req, res) {
  var aws = require("aws-sdk")
  aws.config.update({
    "accessKeyId": "AKIAJDP23FOV42BYHCFA",
    "secretAccessKey": "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"
  })

  if (req.param('session_id')) {
    var sessionId = req.param('session_id');

    var awsdb = new aws.DynamoDB.DocumentClient();

    var params = {
      TableName : "Bitrates",
      KeyConditionExpression: "#ses = :session",
      ExpressionAttributeNames:{
          "#ses": "session_id"
      },
      ExpressionAttributeValues: {
          ":session":sessionId
      }
    };
    awsdb.query(params, function(err, data) {
      if (err) {
          console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
      } else {
          console.log("Query succeeded.");
          console.log(data);
          res.json(data.Items);
      }
    });
  } else
  {
    res.json('session_id is required param');
    res.end();
  }

}


function createBitrate(req, res) {
  console.log(req.body);
  var json = JSON.parse(req.body);
  var sessionId =  json.session_id;
  var bitrateValue = json.bitrate_value;
  var bitrateTimeStamp = json.bitrate_time_stamp;
  var user = json.user;

  var aws = require("aws-sdk")
  aws.config.update({
    "accessKeyId": "AKIAJDP23FOV42BYHCFA",
    "secretAccessKey": "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"
  })

  var awsdb = new aws.DynamoDB.DocumentClient();
  
  var params = {
    TableName:"Bitrates",
    Item:{
        "session_id": sessionId,
        "bitrate_value": bitrateValue,
        "bitrate_time_stamp": bitrateTimeStamp,
        "user": user
    }
  };

  awsdb.put(params, function(err, data) {
    if (err) {
      console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
    } else {
      console.log("Added item:", JSON.stringify(data, null, 2));
      res.json(data);
    }
  });
  res.statusCode = 201;
}