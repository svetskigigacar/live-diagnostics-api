module.exports = {
  aws_table: aws_table
};


var aws = require("aws-sdk")
aws.config.update({"accessKeyId": "aaa",
                   "secretAccessKey": "bbb",
                   "region": "us-east-1",
                   "endpoint":"http://localhost:8000"})

var awsdb = new aws.DynamoDB.DocumentClient();

var params = {
    TableName:"Table1",
    Item:{
        "year": 1985,
        "title": "Naslov1"
    }
};

function aws_table(req, res) {
  // variables defined in the Swagger document can be referenced using req.swagger.params.{parameter_name} 
    awsdb.put(params, function(err, data) {
      if (err) {
        console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
      } else {
        console.log("Added item:", JSON.stringify(data, null, 2));
      }
    });

}